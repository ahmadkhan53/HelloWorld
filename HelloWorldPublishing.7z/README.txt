HelloWorld v1.0
======================
Developer: Ahmad Khan
Date: 31-Oct-2025

Description:
This simple C program prints "Hello, World!" to the screen.

Installation:
1. Extract HelloWorld_v1.0.zip
2. Run HelloWorld.exe

License:
This software is licensed under the MIT License (see LICENSE.txt).
