#include <stdio.h>

// Author: Ahmad Khan
// Program: Hello World!
// Date: 31-Oct-2025
// Version: 1.0.0

int main() {
    printf("Hello, World!\n");
    printf("Welcome to my first published C program.\n");
    getchar();
    return 0;
}
